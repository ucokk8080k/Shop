package id.pahri.ecomenu;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;
import java.util.UUID;

final class PayAmount extends Gui {
    private final UUID target;
    private final String tname;
    private final List<Double> amts;

    PayAmount(EcoMenu p, Player pl, UUID target, String tname) {
        super(p, pl, 3, title("Kirim ke " + tname));
        this.target = target;
        this.tname = tname;
        this.amts = p.getConfig().getDoubleList("pay.amounts");
    }

    @Override
    void draw() {
        fill();
        inv.setItem(4, Items.head(target, tname, "<yellow><bold>" + tname, "<gray>Pilih jumlah yang dikirim"));
        for (int i = 0; i < amts.size() && i < 6; i++) {
            inv.setItem(10 + i, Items.make("GOLD_NUGGET", "<yellow>Kirim " + p.fmt(amts.get(i)),
                    "<gray>Ke: <white>" + tname, "", "<yellow>Klik untuk mengirim"));
        }
        inv.setItem(16, wallet());
        inv.setItem(22, Items.make("ARROW", "<yellow>« Kembali", "<gray>Pilih pemain lain"));
    }

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getSlot();
        if (s == 22) {
            new PaySelect(p, pl).open();
            return;
        }
        int idx = s - 10;
        if (idx >= 0 && idx < amts.size() && idx < 6) {
            if (p.transfer(pl, target, tname, amts.get(idx))) sound(Compat.S_XP, 1.2f);
            draw();
        }
    }
}
