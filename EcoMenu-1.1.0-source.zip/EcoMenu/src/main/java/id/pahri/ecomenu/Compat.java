package id.pahri.ecomenu;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Lapisan kompatibilitas supaya satu jar jalan di Minecraft 1.8 sampai versi terbaru.
 * Semua API yang berubah antar versi (Material, Sound, Enchantment, ActionBar, BlockData, dll)
 * diakses lewat refleksi atau tabel pemetaan di sini.
 */
final class Compat {
    /** Angka minor versi: 1.8 -> 8, 1.21.11 -> 21. Versi bernomor tahun (26.x dst) dianggap 99. */
    static final int MINOR;
    /** true untuk server sebelum 1.13 (nama material lama + data value). */
    static final boolean LEGACY;

    static final String[] S_NO = {"ENTITY_VILLAGER_NO", "VILLAGER_NO"};
    static final String[] S_XP = {"ENTITY_EXPERIENCE_ORB_PICKUP", "ORB_PICKUP"};
    static final String[] S_CLICK = {"UI_BUTTON_CLICK", "CLICK"};
    static final String[] S_LEVEL = {"ENTITY_PLAYER_LEVELUP", "LEVEL_UP"};

    // modern -> {legacyName, data}
    private static final Map<String, String[]> TO_LEGACY = new HashMap<String, String[]>();
    // "LEGACY:data" / "LEGACY:*" -> modern (item)
    private static final Map<String, String> REV = new HashMap<String, String>();
    // legacy block name -> modern block name
    private static final Map<String, String> BREV = new HashMap<String, String>();

    static {
        int m = 21;
        try {
            String[] p = Bukkit.getBukkitVersion().split("-")[0].split("\\.");
            int major = Integer.parseInt(p[0]);
            m = major == 1 ? Integer.parseInt(p[1]) : 99;
        } catch (Exception ignored) {
        }
        MINOR = m;
        LEGACY = m < 13;

        t("GRASS_BLOCK", "GRASS", -1);
        t("OAK_LOG", "LOG", 0);
        t("SPRUCE_LOG", "LOG", 1);
        t("BIRCH_LOG", "LOG", 2);
        t("JUNGLE_LOG", "LOG", 3);
        t("ACACIA_LOG", "LOG_2", 0);
        t("DARK_OAK_LOG", "LOG_2", 1);
        t("OAK_PLANKS", "WOOD", 0);
        t("SPRUCE_PLANKS", "WOOD", 1);
        t("BIRCH_PLANKS", "WOOD", 2);
        t("JUNGLE_PLANKS", "WOOD", 3);
        t("ACACIA_PLANKS", "WOOD", 4);
        t("DARK_OAK_PLANKS", "WOOD", 5);
        t("STONE_BRICKS", "SMOOTH_BRICK", 0);
        t("BRICKS", "BRICK", -1);
        t("TERRACOTTA", "HARD_CLAY", -1);
        t("NETHER_QUARTZ_ORE", "QUARTZ_ORE", -1);
        t("LAPIS_LAZULI", "INK_SACK", 4);
        t("COCOA_BEANS", "INK_SACK", 3);
        t("LIME_DYE", "INK_SACK", 10);
        t("RED_DYE", "INK_SACK", 1);
        t("WHEAT_SEEDS", "SEEDS", -1);
        t("CARROT", "CARROT_ITEM", -1);
        t("POTATO", "POTATO_ITEM", -1);
        t("MELON_SLICE", "MELON", -1);
        t("NETHER_WART", "NETHER_STALK", -1);
        t("COOKED_PORKCHOP", "GRILLED_PORK", -1);
        t("COOKED_COD", "COOKED_FISH", 0);
        t("COOKED_SALMON", "COOKED_FISH", 1);
        t("COD", "RAW_FISH", 0);
        t("SALMON", "RAW_FISH", 1);
        t("TROPICAL_FISH", "RAW_FISH", 2);
        t("PUFFERFISH", "RAW_FISH", 3);
        t("GUNPOWDER", "SULPHUR", -1);
        t("PLAYER_HEAD", "SKULL_ITEM", 3);
        t("CLOCK", "WATCH", -1);
        t("GRAY_STAINED_GLASS_PANE", "STAINED_GLASS_PANE", 7);
        t("ORANGE_STAINED_GLASS_PANE", "STAINED_GLASS_PANE", 1);
        t("REPEATER", "DIODE", -1);
        t("COMPARATOR", "REDSTONE_COMPARATOR", -1);
        t("PISTON", "PISTON_BASE", -1);
        t("STICKY_PISTON", "PISTON_STICKY_BASE", -1);
        t("REDSTONE_TORCH", "REDSTONE_TORCH_ON", -1);
        t("CRAFTING_TABLE", "WORKBENCH", -1);
        t("GOLDEN_CARROT", "GOLDEN_CARROT", -1);

        // nama blok (bukan item) di versi lama
        BREV.put("CROPS", "WHEAT");
        BREV.put("CARROT", "CARROTS");
        BREV.put("POTATO", "POTATOES");
        BREV.put("BEETROOT_BLOCK", "BEETROOTS");
        BREV.put("NETHER_WARTS", "NETHER_WART");
        BREV.put("MELON_BLOCK", "MELON");
        BREV.put("SUGAR_CANE_BLOCK", "SUGAR_CANE");
        BREV.put("GLOWING_REDSTONE_ORE", "REDSTONE_ORE");
        BREV.put("QUARTZ_ORE", "NETHER_QUARTZ_ORE");
    }

    private Compat() {
    }

    private static void t(String modern, String legacy, int data) {
        TO_LEGACY.put(modern, new String[]{legacy, String.valueOf(Math.max(0, data))});
        REV.put(legacy + ":" + (data < 0 ? "*" : String.valueOf(data)), modern);
    }

    // ------------------------------------------------------------------ material

    /** Buat ItemStack dari nama material modern (mis. GRASS_BLOCK). null kalau tidak ada di versi ini. */
    static ItemStack stack(String key, int amount) {
        try {
            if (!LEGACY) {
                Material m = Material.matchMaterial(key);
                return m == null ? null : new ItemStack(m, amount);
            }
            String[] l = TO_LEGACY.get(key);
            Material m = Material.getMaterial(l != null ? l[0] : key);
            if (m == null) return null;
            return new ItemStack(m, amount, (short) (l != null ? Integer.parseInt(l[1]) : 0));
        } catch (Throwable ex) {
            return null;
        }
    }

    static boolean exists(String key) {
        return stack(key, 1) != null;
    }

    /** Nama material modern dari sebuah item (di versi lama dihitung dari type + data). */
    static String keyOf(ItemStack it) {
        if (it == null) return "AIR";
        if (!LEGACY) return it.getType().name();
        return legacyKey(it.getType().name(), it.getDurability(), false);
    }

    static String keyOf(Block b) {
        if (!LEGACY) return b.getType().name();
        return legacyKey(b.getType().name(), b.getData(), true);
    }

    private static String legacyKey(String n, int data, boolean block) {
        if (n.equals("LOG") || n.equals("LOG_2")) data &= 3;
        if (block) {
            String r = BREV.get(n);
            if (r != null) return r;
        }
        String r = REV.get(n + ":" + data);
        if (r == null) r = REV.get(n + ":*");
        return r != null ? r : n;
    }

    // ------------------------------------------------------------------ suara

    private static final Map<String, Object> SND = new HashMap<String, Object>();

    static void sound(Player p, float pitch, String[] names) {
        Object o;
        if (SND.containsKey(names[0])) o = SND.get(names[0]);
        else {
            o = null;
            for (String n : names) {
                try {
                    o = Sound.class.getField(n).get(null);
                    break;
                } catch (Throwable ignored) {
                }
            }
            SND.put(names[0], o);
        }
        if (o == null) return;
        try {
            p.playSound(p.getLocation(), (Sound) o, 0.7f, pitch);
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ enchant glow

    private static Object ench;
    private static boolean enchInit;

    static Object glowEnchant() {
        if (!enchInit) {
            enchInit = true;
            for (String n : new String[]{"DURABILITY", "UNBREAKING", "LUCK", "LUCK_OF_THE_SEA"}) {
                try {
                    Object o = Class.forName("org.bukkit.enchantments.Enchantment")
                            .getMethod("getByName", String.class).invoke(null, n);
                    if (o != null) {
                        ench = o;
                        break;
                    }
                } catch (Throwable ignored) {
                }
            }
        }
        return ench;
    }

    // ------------------------------------------------------------------ inventory / tangan

    static ItemStack hand(Player p) {
        PlayerInventory inv = p.getInventory();
        if (MINOR >= 9) {
            try {
                return (ItemStack) PlayerInventory.class.getMethod("getItemInMainHand").invoke(inv);
            } catch (Throwable ignored) {
            }
        }
        return inv.getItemInHand();
    }

    static void consumeOneFromHand(Player p) {
        PlayerInventory inv = p.getInventory();
        int s = inv.getHeldItemSlot();
        ItemStack it = inv.getItem(s);
        if (it == null) return;
        if (it.getAmount() <= 1) inv.setItem(s, null);
        else it.setAmount(it.getAmount() - 1);
    }

    private static Method getHand;
    private static boolean getHandInit;

    static boolean isMainHand(PlayerInteractEvent e) {
        if (MINOR < 9) return true;
        try {
            if (!getHandInit) {
                getHandInit = true;
                getHand = PlayerInteractEvent.class.getMethod("getHand");
            }
            return getHand == null || "HAND".equals(String.valueOf(getHand.invoke(e)));
        } catch (Throwable ex) {
            return true;
        }
    }

    // ------------------------------------------------------------------ panen matang

    private static Method gbd, gAge, gMax;
    private static Class<?> ageable;
    private static boolean ageInit;

    /** true kalau tanaman sudah matang (atau bukan tanaman bertumbuh). */
    static boolean isRipe(Block b) {
        try {
            if (LEGACY) {
                String t = b.getType().name();
                int max = (t.equals("BEETROOT_BLOCK") || t.equals("NETHER_WARTS")) ? 3 : 7;
                return b.getData() >= max;
            }
            if (!ageInit) {
                ageInit = true;
                ageable = Class.forName("org.bukkit.block.data.Ageable");
                gbd = Block.class.getMethod("getBlockData");
                gAge = ageable.getMethod("getAge");
                gMax = ageable.getMethod("getMaximumAge");
            }
            Object d = gbd.invoke(b);
            if (!ageable.isInstance(d)) return true;
            return ((Integer) gAge.invoke(d)) >= ((Integer) gMax.invoke(d));
        } catch (Throwable ex) {
            return true;
        }
    }

    // ------------------------------------------------------------------ action bar

    private static boolean abInit, abModern, abBroken;
    private static Object abType;
    private static Class<?> bcArray;
    private static Method abFrom, abSend;
    private static Method nmsSerializer, nmsSend, nmsHandle;
    private static Constructor<?> nmsPacket;

    private static String nmsVer;
    private static Class<?> nmsIcbc;

    static void actionBar(Player p, String legacy) {
        if (abBroken) return;
        try {
            if (!abInit) {
                abInit = true;
                try {
                    Class<?> cmt = Class.forName("net.md_5.bungee.api.ChatMessageType");
                    abType = cmt.getField("ACTION_BAR").get(null);
                    Class<?> bc = Class.forName("net.md_5.bungee.api.chat.BaseComponent");
                    Class<?> tc = Class.forName("net.md_5.bungee.api.chat.TextComponent");
                    bcArray = Array.newInstance(bc, 0).getClass();
                    abFrom = tc.getMethod("fromLegacyText", String.class);
                    abSend = Player.Spigot.class.getMethod("sendMessage", cmt, bcArray);
                    abModern = true;
                } catch (Throwable t) {
                    abModern = false;
                    nmsVer = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
                    Class<?> cp = Class.forName("org.bukkit.craftbukkit." + nmsVer + ".entity.CraftPlayer");
                    nmsHandle = cp.getMethod("getHandle");
                    nmsIcbc = Class.forName("net.minecraft.server." + nmsVer + ".IChatBaseComponent");
                    Class<?> ser = null;
                    for (Class<?> c : nmsIcbc.getDeclaredClasses()) {
                        if (c.getSimpleName().equals("ChatSerializer")) ser = c;
                    }
                    nmsSerializer = ser.getMethod("a", String.class);
                    Class<?> pk = Class.forName("net.minecraft.server." + nmsVer + ".PacketPlayOutChat");
                    nmsPacket = pk.getConstructor(nmsIcbc, byte.class);
                }
            }
            if (abModern) {
                Object comps = abFrom.invoke(null, legacy);
                Object spigot = Player.class.getMethod("spigot").invoke(p);
                abSend.invoke(spigot, abType, comps);
            } else {
                String json = "{\"text\":\"" + legacy.replace("\\", "\\\\").replace("\"", "\\\"") + "\"}";
                Object comp = nmsSerializer.invoke(null, json);
                Object packet = nmsPacket.newInstance(comp, (byte) 2);
                Object handle = nmsHandle.invoke(p);
                Object conn = handle.getClass().getField("playerConnection").get(handle);
                if (nmsSend == null) {
                    nmsSend = conn.getClass().getMethod("sendPacket",
                            Class.forName("net.minecraft.server." + nmsVer + ".Packet"));
                }
                nmsSend.invoke(conn, packet);
            }
        } catch (Throwable t) {
            abBroken = true;
            p.sendMessage(legacy);
        }
    }
}
