package id.pahri.ecomenu;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class EcoMenu extends JavaPlugin {

    static final class Cat {
        final String id, name, icon;
        final LinkedHashMap<String, double[]> items;

        Cat(String id, String name, String icon, LinkedHashMap<String, double[]> items) {
            this.id = id;
            this.name = name;
            this.icon = icon;
            this.items = items;
        }
    }

    static final class Job {
        final String id, name, icon, desc;
        final LinkedHashMap<String, Double> pay;

        Job(String id, String name, String icon, String desc, LinkedHashMap<String, Double> pay) {
            this.id = id;
            this.name = name;
            this.icon = icon;
            this.desc = desc;
            this.pay = pay;
        }
    }

    private static final List<String> COMMANDS = Arrays.asList("menu", "balance", "pay", "baltop", "shop", "sell",
            "buy", "worth", "bank", "daily", "jobs", "history", "note", "paytoggle", "eco");

    Data data;
    final LinkedHashMap<String, Cat> shop = new LinkedHashMap<String, Cat>();
    final Map<String, double[]> prices = new HashMap<String, double[]>();
    final LinkedHashMap<String, Job> jobs = new LinkedHashMap<String, Job>();
    final Set<String> payKeys = new HashSet<String>();
    final Set<Location> placed = new HashSet<Location>();

    private DecimalFormat df;
    private String prefix = "";
    private String symbol = "$";
    private double maxBal = 1e12;
    private int skipped;

    private List<Map.Entry<UUID, PData>> topCache;
    private long topTime;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        data = new Data(this);
        data.load();
        loadAll();

        Cmds cmds = new Cmds(this);
        for (String n : COMMANDS) {
            PluginCommand pc = getCommand(n);
            if (pc != null) {
                pc.setExecutor(cmds);
                pc.setTabCompleter(cmds);
            }
        }
        getServer().getPluginManager().registerEvents(new Listeners(this), this);

        // autosave tiap 5 menit
        Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            @Override
            public void run() {
                data.save(true);
            }
        }, 6000L, 6000L);

        // bunga bank
        long ticks = Math.max(1, getConfig().getLong("bank.interest-minutes", 30)) * 60L * 20L;
        Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            @Override
            public void run() {
                payInterest();
            }
        }, ticks, ticks);

        // gaji main online
        if (getConfig().getBoolean("playtime-reward.enabled", true)) {
            long pt = Math.max(1, getConfig().getLong("playtime-reward.interval-minutes", 15)) * 60L * 20L;
            Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
                @Override
                public void run() {
                    playtimeReward();
                }
            }, pt, pt);
        }

        hooks();
        getLogger().info("EcoMenu aktif di Minecraft 1." + (Compat.MINOR == 99 ? "x (versi baru)" : String.valueOf(Compat.MINOR))
                + " - " + shop.size() + " kategori toko, " + jobs.size() + " job dimuat.");
    }

    private void hooks() {
        if (getConfig().getBoolean("vault.enabled", true) && Bukkit.getPluginManager().getPlugin("Vault") != null) {
            try {
                VaultHook.hook(this);
                getLogger().info("Vault ditemukan: EcoMenu terdaftar sebagai provider ekonomi.");
            } catch (Throwable t) {
                getLogger().warning("Gagal hook ke Vault: " + t);
            }
        }
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new PapiHook(this).register();
                getLogger().info("PlaceholderAPI ditemukan: placeholder %ecomenu_...% aktif.");
            } catch (Throwable t) {
                getLogger().warning("Gagal hook ke PlaceholderAPI: " + t);
            }
        }
    }

    @Override
    public void onDisable() {
        if (data != null) data.save(false);
    }

    void loadAll() {
        reloadConfig();
        prefix = getConfig().getString("prefix", "<gold>EcoMenu <dark_gray>» ");
        symbol = getConfig().getString("currency-symbol", "$");
        maxBal = getConfig().getDouble("max-balance", 1e12);
        df = new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));

        shop.clear();
        prices.clear();
        payKeys.clear();
        jobs.clear();
        skipped = 0;

        ConfigurationSection s = getConfig().getConfigurationSection("shop");
        if (s != null) {
            for (String id : s.getKeys(false)) {
                ConfigurationSection c = s.getConfigurationSection(id);
                if (c == null) continue;
                LinkedHashMap<String, double[]> items = new LinkedHashMap<String, double[]>();
                ConfigurationSection is = c.getConfigurationSection("items");
                if (is != null) {
                    for (String k : is.getKeys(false)) {
                        String key = k.toUpperCase(Locale.ROOT);
                        List<Double> l = is.getDoubleList(k);
                        if (l.size() < 2) {
                            getLogger().warning("Format item shop salah: " + id + "." + k);
                            continue;
                        }
                        if (!Compat.exists(key)) {
                            skipped++; // item belum ada di versi Minecraft ini
                            continue;
                        }
                        double[] pr = {l.get(0), l.get(1)};
                        items.put(key, pr);
                        if (!prices.containsKey(key)) prices.put(key, pr);
                    }
                }
                shop.put(id, new Cat(id, c.getString("name", id), c.getString("icon", "CHEST").toUpperCase(Locale.ROOT), items));
            }
        }
        if (skipped > 0) {
            getLogger().info(skipped + " item shop dilewati karena belum ada di versi Minecraft ini.");
        }

        ConfigurationSection js = getConfig().getConfigurationSection("jobs");
        if (js != null) {
            for (String j : js.getKeys(false)) {
                ConfigurationSection jc = js.getConfigurationSection(j);
                if (jc == null) continue;
                LinkedHashMap<String, Double> pay = new LinkedHashMap<String, Double>();
                ConfigurationSection ps = jc.getConfigurationSection("pay");
                if (ps != null) {
                    for (String k : ps.getKeys(false)) {
                        pay.put(k.toUpperCase(Locale.ROOT), ps.getDouble(k));
                        payKeys.add(k.toUpperCase(Locale.ROOT));
                    }
                }
                jobs.put(j, new Job(j, jc.getString("name", j), jc.getString("icon", "IRON_PICKAXE").toUpperCase(Locale.ROOT),
                        jc.getString("desc", ""), pay));
            }
        }
        topCache = null;
    }

    // ---------- util ----------
    double round(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    String fmt(double v) {
        return symbol + df.format(v);
    }

    /** Parse angka dengan akhiran k/m/b/t. Mengembalikan NaN kalau tidak valid. */
    double parseAmount(String in) {
        String s = in.trim().toLowerCase(Locale.ROOT).replace(",", "");
        double mult = 1;
        if (s.length() > 1) {
            char l = s.charAt(s.length() - 1);
            if (l == 'k') mult = 1e3;
            else if (l == 'm') mult = 1e6;
            else if (l == 'b') mult = 1e9;
            else if (l == 't') mult = 1e12;
            if (mult != 1) s = s.substring(0, s.length() - 1);
        }
        try {
            double v = Double.parseDouble(s) * mult;
            return (Double.isNaN(v) || Double.isInfinite(v)) ? Double.NaN : v;
        } catch (NumberFormatException ex) {
            return Double.NaN;
        }
    }

    String nice(String key) {
        return key.toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    String dur(long ms) {
        long h = ms / 3_600_000L;
        long m = (ms / 60_000L) % 60;
        return h + "j " + m + "m";
    }

    String ago(long ms) {
        long s = Math.max(0, (System.currentTimeMillis() - ms) / 1000);
        if (s < 60) return s + " detik lalu";
        if (s < 3600) return (s / 60) + " menit lalu";
        if (s < 86400) return (s / 3600) + " jam lalu";
        return (s / 86400) + " hari lalu";
    }

    void msg(CommandSender s, String m) {
        s.sendMessage(Txt.c(prefix + m));
    }

    void snd(Player pl, String[] s, float pitch) {
        Compat.sound(pl, pitch, s);
    }

    UUID find(String name) {
        Player o = Bukkit.getPlayerExact(name);
        if (o != null) return o.getUniqueId();
        for (Map.Entry<UUID, PData> e : data.map.entrySet()) {
            if (e.getValue().name.equalsIgnoreCase(name)) return e.getKey();
        }
        return null;
    }

    List<Map.Entry<UUID, PData>> top() {
        long now = System.currentTimeMillis();
        if (topCache == null || now - topTime > 10_000L) {
            List<Map.Entry<UUID, PData>> l = new ArrayList<Map.Entry<UUID, PData>>(data.map.entrySet());
            Collections.sort(l, new Comparator<Map.Entry<UUID, PData>>() {
                @Override
                public int compare(Map.Entry<UUID, PData> a, Map.Entry<UUID, PData> b) {
                    return Double.compare(b.getValue().bal + b.getValue().bank, a.getValue().bal + a.getValue().bank);
                }
            });
            topCache = l;
            topTime = now;
        }
        return topCache;
    }

    void log(UUID u, String text) {
        PData d = data.get(u);
        d.history.add(0, System.currentTimeMillis() + "|" + text);
        int max = Math.max(1, Math.min(14, getConfig().getInt("history-size", 10)));
        while (d.history.size() > max) d.history.remove(d.history.size() - 1);
    }

    // ---------- uang ----------
    boolean take(Player pl, double a) {
        return take(pl.getUniqueId(), a);
    }

    boolean take(UUID u, double a) {
        PData d = data.get(u);
        synchronized (d) {
            if (d.bal < a) return false;
            d.bal = round(d.bal - a);
            return true;
        }
    }

    void give(UUID u, double a) {
        PData d = data.get(u);
        synchronized (d) {
            d.bal = round(Math.min(maxBal, d.bal + a));
        }
    }

    boolean transfer(Player from, UUID to, String toName, double amt) {
        double min = getConfig().getDouble("pay.min", 1);
        if (!(amt >= min) || amt > 1e12) {
            msg(from, "<red>Jumlah minimal <yellow>" + fmt(min) + "</yellow>.");
            return false;
        }
        amt = round(amt);
        if (from.getUniqueId().equals(to)) {
            msg(from, "<red>Tidak bisa mengirim ke diri sendiri.");
            return false;
        }
        PData td = data.get(to);
        if (!td.acceptPay) {
            msg(from, "<red>" + toName + " sedang menolak pembayaran.");
            return false;
        }
        if (!take(from, amt)) {
            msg(from, "<red>Saldo tidak cukup.");
            snd(from, Compat.S_NO, 1f);
            return false;
        }
        double tax = round(amt * Math.max(0, getConfig().getDouble("pay.tax-percent", 0)) / 100.0);
        double recv = round(amt - tax);
        give(to, recv);
        msg(from, "<green>Berhasil mengirim <yellow>" + fmt(amt) + "</yellow> ke <white>" + toName + "</white>."
                + (tax > 0 ? " <gray>(pajak " + fmt(tax) + ")" : ""));
        log(from.getUniqueId(), "<red>-" + fmt(amt) + " <gray>kirim ke " + toName);
        log(to, "<green>+" + fmt(recv) + " <gray>dari " + from.getName());
        Player t = Bukkit.getPlayer(to);
        if (t != null) {
            msg(t, "<green>Kamu menerima <yellow>" + fmt(recv) + "</yellow> dari <white>" + from.getName() + "</white>.");
            snd(t, Compat.S_XP, 1f);
        }
        return true;
    }

    // ---------- shop ----------
    double sellMult(Player pl) {
        double best = 1;
        ConfigurationSection s = getConfig().getConfigurationSection("sell-multipliers");
        if (s != null) {
            for (String k : s.getKeys(false)) {
                if (pl.hasPermission("ecomenu.multiplier." + k)) best = Math.max(best, s.getDouble(k, 1));
            }
        }
        return best;
    }

    boolean buy(Player pl, String key, int amt) {
        double[] pr = prices.get(key);
        if (pr == null || pr[0] < 0) {
            msg(pl, "<red>Item ini tidak dijual.");
            return false;
        }
        double cost = round(pr[0] * amt);
        if (!take(pl, cost)) {
            msg(pl, "<red>Saldo tidak cukup. Butuh <yellow>" + fmt(cost) + "</yellow>.");
            snd(pl, Compat.S_NO, 1f);
            return false;
        }
        ItemStack st = Compat.stack(key, amt);
        if (st == null) {
            give(pl.getUniqueId(), cost);
            msg(pl, "<red>Item tidak tersedia di versi ini.");
            return false;
        }
        Map<Integer, ItemStack> left = pl.getInventory().addItem(st);
        int rest = 0;
        for (ItemStack r : left.values()) rest += r.getAmount();
        if (rest > 0) give(pl.getUniqueId(), round(pr[0] * rest));
        int got = amt - rest;
        if (got <= 0) {
            msg(pl, "<red>Inventory penuh.");
            return false;
        }
        double paid = round(pr[0] * got);
        msg(pl, "<green>Membeli <yellow>" + got + "x " + nice(key) + "</yellow> seharga <gold>" + fmt(paid) + "</gold>.");
        log(pl.getUniqueId(), "<red>-" + fmt(paid) + " <gray>beli " + got + "x " + nice(key));
        return true;
    }

    int sellKey(Player pl, String key, int max) {
        double[] pr = prices.get(key);
        if (pr == null || pr[1] < 0) {
            msg(pl, "<red>Item ini tidak bisa dijual.");
            return 0;
        }
        PlayerInventory inv = pl.getInventory();
        int left = max, sold = 0;
        for (int i = 0; i < 36 && left > 0; i++) {
            ItemStack it = inv.getItem(i);
            if (it == null || it.hasItemMeta() || !Compat.keyOf(it).equals(key)) continue;
            int t = Math.min(left, it.getAmount());
            sold += t;
            left -= t;
            if (t == it.getAmount()) inv.setItem(i, null);
            else it.setAmount(it.getAmount() - t);
        }
        if (sold == 0) {
            msg(pl, "<red>Kamu tidak punya item itu.");
            return 0;
        }
        double mult = sellMult(pl);
        double g = round(pr[1] * sold * mult);
        give(pl.getUniqueId(), g);
        msg(pl, "<green>Menjual <yellow>" + sold + "x " + nice(key) + "</yellow> dan dapat <gold>" + fmt(g) + "</gold>"
                + (mult > 1 ? " <gray>(x" + mult + ")" : "") + ".");
        log(pl.getUniqueId(), "<green>+" + fmt(g) + " <gray>jual " + sold + "x " + nice(key));
        return sold;
    }

    double sellAll(Player pl) {
        double total = 0;
        int count = 0;
        PlayerInventory inv = pl.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack it = inv.getItem(i);
            if (it == null || it.hasItemMeta()) continue;
            double[] pr = prices.get(Compat.keyOf(it));
            if (pr == null || pr[1] < 0) continue;
            total += pr[1] * it.getAmount();
            count += it.getAmount();
            inv.setItem(i, null);
        }
        if (count == 0) {
            msg(pl, "<red>Tidak ada item yang bisa dijual.");
            snd(pl, Compat.S_NO, 1f);
            return 0;
        }
        double mult = sellMult(pl);
        total = round(total * mult);
        give(pl.getUniqueId(), total);
        msg(pl, "<green>Menjual <yellow>" + count + " item</yellow> dan dapat <gold>" + fmt(total) + "</gold>"
                + (mult > 1 ? " <gray>(x" + mult + ")" : "") + ".");
        log(pl.getUniqueId(), "<green>+" + fmt(total) + " <gray>jual semua (" + count + " item)");
        snd(pl, Compat.S_XP, 1.2f);
        return total;
    }

    void sellHand(Player pl) {
        ItemStack h = Compat.hand(pl);
        if (h == null || h.getType() == org.bukkit.Material.AIR) {
            msg(pl, "<red>Pegang item yang mau dijual.");
            return;
        }
        if (h.hasItemMeta()) {
            msg(pl, "<red>Item custom tidak bisa dijual.");
            return;
        }
        if (sellKey(pl, Compat.keyOf(h), h.getAmount()) > 0) snd(pl, Compat.S_XP, 1.2f);
    }

    // ---------- banknote ----------
    void createNote(Player pl, double amt) {
        double min = getConfig().getDouble("banknote.min", 100);
        if (!getConfig().getBoolean("banknote.enabled", true)) {
            msg(pl, "<red>Banknote dinonaktifkan.");
            return;
        }
        if (!(amt >= min) || amt > 1e12) {
            msg(pl, "<red>Nilai banknote minimal <yellow>" + fmt(min) + "</yellow>.");
            return;
        }
        amt = round(amt);
        if (!take(pl, amt)) {
            msg(pl, "<red>Saldo tidak cukup.");
            snd(pl, Compat.S_NO, 1f);
            return;
        }
        String id = UUID.randomUUID().toString().replace("-", "").substring(0, 10);
        ItemStack it = Items.make("PAPER", "<green><bold>Banknote <yellow>" + fmt(amt),
                "<gray>Klik kanan untuk menukar ke saldo.", "", "<dark_gray>ID: " + id);
        it = Items.glow(it);
        Map<Integer, ItemStack> left = pl.getInventory().addItem(it);
        if (!left.isEmpty()) {
            give(pl.getUniqueId(), amt);
            msg(pl, "<red>Inventory penuh.");
            return;
        }
        data.notes.put(id, amt);
        log(pl.getUniqueId(), "<red>-" + fmt(amt) + " <gray>cetak banknote");
        msg(pl, "<green>Banknote <yellow>" + fmt(amt) + "</yellow> dibuat. Klik kanan untuk menukarnya kembali.");
    }

    /** @return true kalau item itu banknote (event boleh dibatalkan). */
    boolean redeemNote(Player pl, ItemStack it) {
        ItemMeta m = it.getItemMeta();
        if (m == null || m.getLore() == null || m.getLore().isEmpty()) return false;
        List<String> lore = m.getLore();
        String last = Txt.strip(lore.get(lore.size() - 1)).trim();
        if (!last.startsWith("ID: ")) return false;
        String id = last.substring(4).trim();
        Double amt = data.notes.remove(id);
        if (amt == null) {
            msg(pl, "<red>Banknote ini tidak valid atau sudah ditukar.");
            return true;
        }
        Compat.consumeOneFromHand(pl);
        give(pl.getUniqueId(), amt);
        log(pl.getUniqueId(), "<green>+" + fmt(amt) + " <gray>tukar banknote");
        msg(pl, "<green>Banknote ditukar: <gold>+" + fmt(amt));
        snd(pl, Compat.S_XP, 1.2f);
        return true;
    }

    // ---------- daily ----------
    long cooldownMs() {
        return getConfig().getLong("daily.cooldown-hours", 24) * 3_600_000L;
    }

    long dailyRemaining(PData d) {
        return Math.max(0, d.lastDaily + cooldownMs() - System.currentTimeMillis());
    }

    void daily(Player pl) {
        PData d = data.get(pl.getUniqueId());
        long rem = dailyRemaining(d);
        if (rem > 0) {
            msg(pl, "<red>Hadiah harian sudah diambil. Coba lagi dalam <yellow>" + dur(rem) + "</yellow>.");
            snd(pl, Compat.S_NO, 1f);
            return;
        }
        long now = System.currentTimeMillis();
        d.streak = (d.lastDaily > 0 && now - d.lastDaily <= cooldownMs() * 2) ? d.streak + 1 : 1;
        int cap = Math.max(1, getConfig().getInt("daily.max-streak-days", 7));
        double r = getConfig().getDouble("daily.base", 500)
                + Math.min(d.streak - 1, cap - 1) * getConfig().getDouble("daily.streak-bonus", 100);
        d.lastDaily = now;
        give(pl.getUniqueId(), r);
        log(pl.getUniqueId(), "<green>+" + fmt(r) + " <gray>hadiah harian");
        msg(pl, "<green>Hadiah harian: <gold>" + fmt(r) + "</gold> <gray>(streak " + d.streak + " hari)");
        snd(pl, Compat.S_LEVEL, 1f);
    }

    // ---------- bank ----------
    void payInterest() {
        double rate = getConfig().getDouble("bank.interest-percent", 1) / 100.0;
        double max = getConfig().getDouble("bank.max-interest", 5000);
        for (Map.Entry<UUID, PData> e : data.map.entrySet()) {
            PData d = e.getValue();
            if (d.bank <= 0) continue;
            double i = round(Math.min(d.bank * rate, max));
            if (i <= 0) continue;
            d.bank = round(d.bank + i);
            Player pl = Bukkit.getPlayer(e.getKey());
            if (pl != null) msg(pl, "<green>Bunga bank masuk: <gold>+" + fmt(i) + "</gold>");
        }
    }

    /** @return true kalau berhasil. amount &lt; 0 berarti "semua". */
    boolean bankMove(Player pl, boolean deposit, double amount) {
        PData d = data.get(pl.getUniqueId());
        double src = deposit ? d.bal : d.bank;
        double amt = round(amount < 0 ? src : amount);
        if (amt <= 0 || src < amt) {
            msg(pl, "<red>Saldo tidak cukup.");
            snd(pl, Compat.S_NO, 1f);
            return false;
        }
        synchronized (d) {
            if (deposit) {
                d.bal = round(d.bal - amt);
                d.bank = round(d.bank + amt);
            } else {
                d.bank = round(d.bank - amt);
                d.bal = round(Math.min(maxBal, d.bal + amt));
            }
        }
        msg(pl, "<green>" + (deposit ? "Menyetor" : "Menarik") + " <yellow>" + fmt(amt) + "</yellow> "
                + (deposit ? "ke bank." : "dari bank."));
        snd(pl, Compat.S_XP, 1f);
        return true;
    }

    // ---------- reward & penalti ----------
    void playtimeReward() {
        double amt = getConfig().getDouble("playtime-reward.amount", 50);
        if (amt <= 0) return;
        for (Player pl : Bukkit.getOnlinePlayers()) {
            give(pl.getUniqueId(), amt);
            Compat.actionBar(pl, Txt.c("<green>+" + fmt(amt) + " <gray>gaji main online"));
        }
    }

    void deathPenalty(Player victim, Player killer) {
        double pct = getConfig().getDouble("death-penalty.percent", 0);
        if (pct <= 0 || victim.hasPermission("ecomenu.deathpenalty.bypass")) return;
        PData d = data.get(victim.getUniqueId());
        double lose = round(d.bal * Math.min(100, pct) / 100.0);
        if (lose <= 0 || !take(victim, lose)) return;
        msg(victim, "<red>Kamu kehilangan <yellow>" + fmt(lose) + "</yellow> karena mati.");
        log(victim.getUniqueId(), "<red>-" + fmt(lose) + " <gray>penalti mati");
        if (killer != null && !killer.equals(victim) && getConfig().getBoolean("death-penalty.give-to-killer", false)) {
            give(killer.getUniqueId(), lose);
            msg(killer, "<green>Kamu mendapat <yellow>" + fmt(lose) + "</yellow> dari " + victim.getName() + ".");
            log(killer.getUniqueId(), "<green>+" + fmt(lose) + " <gray>bunuh " + victim.getName());
        }
    }

    // ---------- jobs ----------
    int level(PData d, String job) {
        int per = Math.max(1, getConfig().getInt("job-xp-per-level", 150));
        int max = Math.max(1, getConfig().getInt("job-max-level", 100));
        return Math.min(max, 1 + d.xp.getOrDefault(job, 0) / per);
    }

    double bonusPerLevel() {
        return getConfig().getDouble("job-bonus-percent", 5);
    }

    double jobAmount(Player pl, String key) {
        PData d = data.get(pl.getUniqueId());
        if (d.job.isEmpty()) return 0;
        Job j = jobs.get(d.job);
        if (j == null) return 0;
        Double v = j.pay.get(key);
        return v == null ? 0 : v;
    }

    void jobPay(Player pl, double base) {
        PData d = data.get(pl.getUniqueId());
        Job j = jobs.get(d.job);
        if (j == null) return;
        int lv = level(d, d.job);
        double amt = round(base * (1 + bonusPerLevel() / 100.0 * (lv - 1)));
        give(pl.getUniqueId(), amt);
        d.xp.put(d.job, d.xp.getOrDefault(d.job, 0) + 1);
        int nl = level(d, d.job);
        Compat.actionBar(pl, Txt.c("<green>+" + fmt(amt) + " <gray>(" + j.name + " <gray>Lv." + nl + ")"));
        if (nl > lv) {
            msg(pl, "<gold>Level job naik ke <yellow>" + nl + "</yellow>! Bonus gaji +" + (int) ((nl - 1) * bonusPerLevel()) + "%");
            snd(pl, Compat.S_LEVEL, 1f);
        }
    }

    boolean joinJob(Player pl, String id) {
        Job j = null;
        for (Job x : jobs.values()) if (x.id.equalsIgnoreCase(id)) j = x;
        if (j == null) {
            msg(pl, "<red>Job tidak ditemukan.");
            return false;
        }
        PData d = data.get(pl.getUniqueId());
        if (j.id.equals(d.job)) {
            msg(pl, "<yellow>Kamu sudah menjadi " + j.name + "<yellow>.");
            return false;
        }
        d.job = j.id;
        msg(pl, "<green>Sekarang kamu bekerja sebagai " + j.name + "<green>!");
        snd(pl, Compat.S_LEVEL, 1.2f);
        return true;
    }

    void leaveJob(Player pl) {
        PData d = data.get(pl.getUniqueId());
        if (d.job.isEmpty()) {
            msg(pl, "<red>Kamu tidak punya pekerjaan.");
            return;
        }
        d.job = "";
        msg(pl, "<yellow>Kamu keluar dari pekerjaanmu.");
    }
}
