package id.pahri.ecomenu;

import org.bukkit.Bukkit;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

final class Items {
    private Items() {
    }

    static String t(String s) {
        return "§r" + Txt.c(s);
    }

    static List<String> lore(List<String> lines) {
        List<String> l = new ArrayList<String>();
        for (String s : lines) l.add(t(s));
        return l;
    }

    static ItemStack base(String key) {
        ItemStack it = Compat.stack(key, 1);
        if (it == null) it = Compat.stack("PAPER", 1);
        return it;
    }

    static ItemStack make(String key, String name, String... lore) {
        return make(key, name, Arrays.asList(lore));
    }

    static ItemStack make(String key, String name, List<String> lore) {
        ItemStack it = base(key);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(t(name));
        if (!lore.isEmpty()) meta.setLore(lore(lore));
        meta.addItemFlags(ItemFlag.values());
        it.setItemMeta(meta);
        return it;
    }

    static ItemStack glow(ItemStack it) {
        Object e = Compat.glowEnchant();
        if (e == null) return it;
        ItemMeta meta = it.getItemMeta();
        meta.addEnchant((Enchantment) e, 1, true);
        meta.addItemFlags(ItemFlag.values());
        it.setItemMeta(meta);
        return it;
    }

    static ItemStack head(UUID id, String owner, String name, String... lore) {
        ItemStack it = Compat.stack("PLAYER_HEAD", 1);
        if (it == null) return make("PAPER", name, lore);
        SkullMeta sm = (SkullMeta) it.getItemMeta();
        boolean done = false;
        if (Compat.MINOR >= 12 && id != null) {
            try {
                SkullMeta.class.getMethod("setOwningPlayer", org.bukkit.OfflinePlayer.class)
                        .invoke(sm, Bukkit.getOfflinePlayer(id));
                done = true;
            } catch (Throwable ignored) {
            }
        }
        if (!done && owner != null && !owner.equals("?")) sm.setOwner(owner);
        sm.setDisplayName(t(name));
        if (lore.length > 0) sm.setLore(lore(Arrays.asList(lore)));
        it.setItemMeta(sm);
        return it;
    }
}
