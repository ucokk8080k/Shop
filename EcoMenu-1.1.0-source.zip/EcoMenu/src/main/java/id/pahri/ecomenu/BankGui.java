package id.pahri.ecomenu;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class BankGui extends Gui {
    private final List<Double> amts = new ArrayList<Double>();

    BankGui(EcoMenu p, Player pl) {
        super(p, pl, 4, title("Bank"));
        List<Double> l = p.getConfig().getDoubleList("bank.amounts");
        for (int i = 0; i < Math.min(3, l.size()); i++) amts.add(l.get(i));
        if (amts.isEmpty()) amts.addAll(Arrays.asList(100.0, 1000.0, 10000.0));
    }

    @Override
    void draw() {
        fill();
        PData d = p.data.get(pl.getUniqueId());
        for (int i = 0; i <= amts.size(); i++) {
            boolean all = i == amts.size();
            String a = all ? "semua" : p.fmt(amts.get(i));
            inv.setItem(10 + i, Items.make("LIME_DYE", "<green><bold>Setor " + a,
                    "<gray>Dompet → Bank", "", "<yellow>Klik untuk menyetor"));
            inv.setItem(19 + i, Items.make("RED_DYE", "<red><bold>Tarik " + a,
                    "<gray>Bank → Dompet", "", "<yellow>Klik untuk menarik"));
        }
        inv.setItem(16, Items.make("GOLD_BLOCK", "<gold><bold>Info Bank",
                "<gray>Dompet: <green>" + p.fmt(d.bal),
                "<gray>Bank: <aqua>" + p.fmt(d.bank),
                "",
                "<gray>Bunga: <yellow>" + p.getConfig().getDouble("bank.interest-percent", 1) + "%</yellow> tiap <yellow>"
                        + p.getConfig().getLong("bank.interest-minutes", 30) + " menit",
                "<gray>Maks bunga: <yellow>" + p.fmt(p.getConfig().getDouble("bank.max-interest", 5000))));
        inv.setItem(31, back());
    }

    private void move(boolean dep, int idx) {
        double amt = idx >= amts.size() ? -1 : amts.get(idx);
        p.bankMove(pl, dep, amt);
        draw();
    }

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getSlot();
        if (s == 31) {
            new MainMenu(p, pl).open();
            return;
        }
        if (s >= 10 && s <= 10 + amts.size()) move(true, s - 10);
        else if (s >= 19 && s <= 19 + amts.size()) move(false, s - 19);
    }
}
