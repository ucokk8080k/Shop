package id.pahri.ecomenu;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Konverter teks gaya MiniMessage (&lt;red&gt;, &lt;bold&gt;, &lt;#rrggbb&gt;, &lt;gradient:#a:#b&gt;) dan kode &amp;
 * menjadi string legacy (kode section) yang jalan di SEMUA versi Minecraft.
 * Di bawah 1.16 warna hex otomatis diubah ke warna terdekat dari 16 warna standar.
 */
final class Txt {
    private static final char SEC = '§';
    private static final String[] NAMES = {"black", "dark_blue", "dark_green", "dark_aqua", "dark_red",
            "dark_purple", "gold", "gray", "dark_gray", "blue", "green", "aqua", "red", "light_purple",
            "yellow", "white"};
    private static final int[] RGB = {0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xFFAA00,
            0xAAAAAA, 0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF};
    private static final String CODES = "0123456789abcdef";
    private static final Map<String, Integer> NAMED = new HashMap<String, Integer>();
    private static final Pattern TAGS = Pattern.compile("<[^>]*>");
    private static final Pattern STRIP = Pattern.compile("(?i)§x(§[0-9a-f]){6}|§[0-9a-fk-or]");
    private static final boolean HEX = Compat.MINOR >= 16;

    static {
        for (int i = 0; i < NAMES.length; i++) NAMED.put(NAMES[i], RGB[i]);
        NAMED.put("grey", RGB[7]);
        NAMED.put("dark_grey", RGB[8]);
    }

    private static final class St {
        int color = -1;
        boolean b, i, u, s, o;
        boolean grad;
        int g1, g2, gTotal, gIdx;
        String last;

        void reset() {
            color = -1;
            b = i = u = s = o = false;
            grad = false;
        }
    }

    private Txt() {
    }

    /** Hapus semua kode warna dari string legacy. */
    static String strip(String s) {
        return s == null ? "" : STRIP.matcher(s).replaceAll("");
    }

    static String c(String in) {
        if (in == null || in.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        St st = new St();
        int n = in.length();
        String low = in.toLowerCase(Locale.ROOT);
        for (int p = 0; p < n; p++) {
            char ch = in.charAt(p);
            if (ch == '<') {
                int e = in.indexOf('>', p);
                if (e > p && tag(in, low, p, e, st)) {
                    p = e;
                    continue;
                }
            }
            if ((ch == '&' || ch == SEC) && p + 1 < n) {
                char k = Character.toLowerCase(in.charAt(p + 1));
                int ci = CODES.indexOf(k);
                if (ci >= 0) {
                    st.color = RGB[ci];
                    st.b = st.i = st.u = st.s = st.o = false;
                    st.grad = false;
                    p++;
                    continue;
                }
                if (k == 'l') { st.b = true; p++; continue; }
                if (k == 'o') { st.i = true; p++; continue; }
                if (k == 'n') { st.u = true; p++; continue; }
                if (k == 'm') { st.s = true; p++; continue; }
                if (k == 'k') { st.o = true; p++; continue; }
                if (k == 'r') { st.reset(); p++; continue; }
            }
            put(sb, st, ch);
        }
        return sb.toString();
    }

    private static boolean tag(String in, String low, int p, int e, St st) {
        String t = low.substring(p + 1, e);
        boolean closing = t.startsWith("/");
        if (closing) t = t.substring(1);
        if (t.startsWith("!")) return true; // <!italic> dll: diabaikan, lore sudah non-italic
        switch (t) {
            case "reset":
            case "r":
                st.reset();
                return true;
            case "bold":
            case "b":
                st.b = !closing;
                return true;
            case "italic":
            case "i":
            case "em":
                st.i = !closing;
                return true;
            case "underlined":
            case "u":
                st.u = !closing;
                return true;
            case "strikethrough":
            case "st":
                st.s = !closing;
                return true;
            case "obfuscated":
            case "obf":
                st.o = !closing;
                return true;
            default:
                break;
        }
        if (t.startsWith("gradient")) {
            if (closing) {
                st.grad = false;
                return true;
            }
            String[] a = t.split(":");
            if (a.length < 3) return false;
            Integer c1 = parseColor(a[1]);
            Integer c2 = parseColor(a[a.length - 1]);
            if (c1 == null || c2 == null) return false;
            int end = low.indexOf("</gradient>", e + 1);
            String inner = in.substring(e + 1, end < 0 ? in.length() : end);
            st.gTotal = TAGS.matcher(inner).replaceAll("").length();
            st.gIdx = 0;
            st.g1 = c1;
            st.g2 = c2;
            st.grad = true;
            return true;
        }
        Integer col = parseColor(t.startsWith("color:") ? t.substring(6) : t);
        if (col == null) return false;
        if (closing) st.color = -1;
        else {
            st.color = col;
            st.grad = false;
        }
        return true;
    }

    private static Integer parseColor(String s) {
        Integer v = NAMED.get(s);
        if (v != null) return v;
        if (s.length() == 7 && s.charAt(0) == '#') {
            try {
                return Integer.parseInt(s.substring(1), 16);
            } catch (NumberFormatException ignored) {
            }
        }
        return null;
    }

    private static void put(StringBuilder sb, St st, char ch) {
        int col = st.color;
        if (st.grad) {
            double t = st.gTotal <= 1 ? 0 : (double) st.gIdx / (st.gTotal - 1);
            st.gIdx++;
            int r = (int) Math.round(((st.g1 >> 16) & 255) + (((st.g2 >> 16) & 255) - ((st.g1 >> 16) & 255)) * t);
            int g = (int) Math.round(((st.g1 >> 8) & 255) + (((st.g2 >> 8) & 255) - ((st.g1 >> 8) & 255)) * t);
            int b = (int) Math.round((st.g1 & 255) + ((st.g2 & 255) - (st.g1 & 255)) * t);
            col = (r << 16) | (g << 8) | b;
        }
        StringBuilder style = new StringBuilder();
        if (col < 0) style.append(SEC).append('r');
        else style.append(colorSeq(col));
        if (st.b) style.append(SEC).append('l');
        if (st.i) style.append(SEC).append('o');
        if (st.u) style.append(SEC).append('n');
        if (st.s) style.append(SEC).append('m');
        if (st.o) style.append(SEC).append('k');
        String s = style.toString();
        if (!s.equals(st.last)) {
            sb.append(s);
            st.last = s;
        }
        sb.append(ch);
    }

    private static String colorSeq(int rgb) {
        for (int i = 0; i < RGB.length; i++) {
            if (RGB[i] == rgb) return "" + SEC + CODES.charAt(i);
        }
        if (HEX) {
            String h = String.format("%06x", rgb & 0xFFFFFF);
            StringBuilder b = new StringBuilder().append(SEC).append('x');
            for (int i = 0; i < 6; i++) b.append(SEC).append(h.charAt(i));
            return b.toString();
        }
        int best = 0;
        long bd = Long.MAX_VALUE;
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, bl = rgb & 255;
        for (int i = 0; i < RGB.length; i++) {
            int dr = r - ((RGB[i] >> 16) & 255), dg = g - ((RGB[i] >> 8) & 255), db = bl - (RGB[i] & 255);
            long d = (long) dr * dr + (long) dg * dg + (long) db * db;
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        return "" + SEC + CODES.charAt(best);
    }
}
