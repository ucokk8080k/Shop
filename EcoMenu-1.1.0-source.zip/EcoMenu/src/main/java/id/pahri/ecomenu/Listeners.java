package id.pahri.ecomenu;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

final class Listeners implements Listener {
    /** Tanaman yang hanya dibayar kalau sudah matang. */
    private static final Set<String> CROPS = new HashSet<String>(Arrays.asList(
            "WHEAT", "CARROTS", "POTATOES", "BEETROOTS", "NETHER_WART"));
    /** Blok yang tidak perlu dilacak "buatan pemain" (tumbuh lagi / panen berulang). */
    private static final Set<String> UNTRACKED = new HashSet<String>(Arrays.asList(
            "WHEAT", "CARROTS", "POTATOES", "BEETROOTS", "NETHER_WART", "SUGAR_CANE", "CACTUS", "BAMBOO"));

    private final EcoMenu p;

    Listeners(EcoMenu p) {
        this.p = p;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        InventoryHolder h = e.getInventory().getHolder();
        if (h instanceof Gui) {
            e.setCancelled(true);
            int raw = e.getRawSlot();
            if (raw >= 0 && raw < e.getInventory().getSize() && e.getWhoClicked() instanceof Player) {
                ((Gui) h).click(e);
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Gui) e.setCancelled(true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        final Player pl = e.getPlayer();
        final PData d = p.data.get(pl.getUniqueId());
        d.name = pl.getName();
        Bukkit.getScheduler().runTaskLater(p, new Runnable() {
            @Override
            public void run() {
                if (pl.isOnline() && p.dailyRemaining(d) <= 0) {
                    p.msg(pl, "<yellow>Hadiah harian siap! Ketik <gold>/daily</gold> atau buka <gold>/menu</gold>.");
                }
            }
        }, 60L);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        String k = Compat.keyOf(e.getBlockPlaced());
        if (UNTRACKED.contains(k)) return;
        if (p.payKeys.contains(k)) {
            if (p.placed.size() > 100_000) p.placed.clear();
            p.placed.add(e.getBlockPlaced().getLocation());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player pl = e.getPlayer();
        if (pl.getGameMode() == GameMode.CREATIVE) return;
        Block b = e.getBlock();
        if (p.placed.remove(b.getLocation())) return; // blok buatan pemain tidak dibayar
        String k = Compat.keyOf(b);
        double base = p.jobAmount(pl, k);
        if (base <= 0) return;
        if (CROPS.contains(k) && !Compat.isRipe(b)) return;
        p.jobPay(pl, base);
    }

    @EventHandler(ignoreCancelled = true)
    public void onKill(EntityDeathEvent e) {
        if (e.getEntity() instanceof Player) return;
        Player k = e.getEntity().getKiller();
        if (k == null) return;
        double base = p.jobAmount(k, e.getEntityType().name());
        if (base > 0) p.jobPay(k, base);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFish(PlayerFishEvent e) {
        if (e.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        Entity c = e.getCaught();
        if (!(c instanceof Item)) return;
        ItemStack it = ((Item) c).getItemStack();
        double base = p.jobAmount(e.getPlayer(), Compat.keyOf(it));
        if (base > 0) p.jobPay(e.getPlayer(), base);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        p.deathPenalty(e.getEntity(), e.getEntity().getKiller());
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null || it.getType() != Material.PAPER || !it.hasItemMeta()) return;
        if (!Compat.isMainHand(e)) return;
        if (p.redeemNote(e.getPlayer(), it)) e.setCancelled(true);
    }
}
