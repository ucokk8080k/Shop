package id.pahri.ecomenu;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;
import java.util.Map;
import java.util.UUID;

final class TopGui extends Gui {
    private static final int[] SLOTS = {10, 11, 12, 13, 14, 15, 16, 20, 22, 24};
    private static final String[] COLORS = {"<gold>", "<white>", "<#cd7f32>"};

    TopGui(EcoMenu p, Player pl) {
        super(p, pl, 4, title("Top Terkaya"));
    }

    @Override
    void draw() {
        fill();
        List<Map.Entry<UUID, PData>> l = p.top();
        for (int i = 0; i < SLOTS.length && i < l.size(); i++) {
            Map.Entry<UUID, PData> e = l.get(i);
            PData d = e.getValue();
            String c = i < 3 ? COLORS[i] : "<yellow>";
            inv.setItem(SLOTS[i], Items.head(e.getKey(), d.name, c + "<bold>#" + (i + 1) + " " + d.name,
                    "<gray>Total: <green>" + p.fmt(d.bal + d.bank),
                    "<gray>Dompet: <white>" + p.fmt(d.bal),
                    "<gray>Bank: <aqua>" + p.fmt(d.bank)));
        }
        inv.setItem(4, Items.make("NETHER_STAR", "<light_purple><bold>Leaderboard", "<gray>Dompet + Bank"));
        inv.setItem(31, back());
    }

    @Override
    void click(InventoryClickEvent e) {
        if (e.getSlot() == 31) new MainMenu(p, pl).open();
    }
}
