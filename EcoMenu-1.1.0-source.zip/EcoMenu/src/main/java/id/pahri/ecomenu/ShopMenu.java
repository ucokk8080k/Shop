package id.pahri.ecomenu;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;

final class ShopMenu extends Gui {
    private final List<EcoMenu.Cat> cats = new ArrayList<EcoMenu.Cat>();

    ShopMenu(EcoMenu p, Player pl) {
        super(p, pl, 4, title("Toko"));
    }

    private int slot(int i) {
        return 10 + (i / 7) * 9 + i % 7;
    }

    @Override
    void draw() {
        fill();
        cats.clear();
        cats.addAll(p.shop.values());
        inv.setItem(4, wallet());
        for (int i = 0; i < cats.size() && i < 14; i++) {
            EcoMenu.Cat c = cats.get(i);
            inv.setItem(slot(i), Items.make(c.icon, c.name,
                    "<gray>" + c.items.size() + " item", "", "<yellow>Klik untuk membuka"));
        }
        inv.setItem(31, back());
    }

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getSlot();
        if (s == 31) {
            new MainMenu(p, pl).open();
            sound(Compat.S_CLICK, 1f);
            return;
        }
        for (int i = 0; i < cats.size() && i < 14; i++) {
            if (slot(i) == s) {
                new ShopItems(p, pl, cats.get(i), 0).open();
                sound(Compat.S_CLICK, 1f);
                return;
            }
        }
    }
}
