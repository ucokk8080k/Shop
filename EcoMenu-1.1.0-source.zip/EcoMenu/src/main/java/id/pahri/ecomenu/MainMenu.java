package id.pahri.ecomenu;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

final class MainMenu extends Gui {

    MainMenu(EcoMenu p, Player pl) {
        super(p, pl, 6, title("Menu Ekonomi"));
    }

    @Override
    void draw() {
        fill();
        PData d = p.data.get(pl.getUniqueId());
        EcoMenu.Job j = p.jobs.get(d.job);
        inv.setItem(4, Items.head(pl.getUniqueId(), pl.getName(), "<yellow><bold>" + pl.getName(),
                "<gray>Dompet: <green>" + p.fmt(d.bal),
                "<gray>Bank: <aqua>" + p.fmt(d.bank),
                "<gray>Total: <gold>" + p.fmt(d.bal + d.bank),
                "",
                "<gray>Pekerjaan: " + (j == null ? "<red>belum ada" : j.name)));

        inv.setItem(10, Items.make("EMERALD", "<green><bold>Toko",
                "<gray>Beli dan jual berbagai item.", "", "<yellow>Klik untuk membuka"));
        inv.setItem(12, Items.make("GOLD_INGOT", "<gold><bold>Bank",
                "<gray>Simpan uang & dapat bunga.", "<gray>Tersimpan: <aqua>" + p.fmt(d.bank), "", "<yellow>Klik untuk membuka"));

        long rem = p.dailyRemaining(d);
        ItemStack daily = Items.make(rem <= 0 ? "CLOCK" : "BARRIER", "<aqua><bold>Hadiah Harian",
                "<gray>Streak: <yellow>" + d.streak + " hari", "",
                rem <= 0 ? "<green>Siap diklaim! Klik sekarang" : "<red>Tunggu " + p.dur(rem));
        inv.setItem(14, rem <= 0 ? Items.glow(daily) : daily);

        inv.setItem(16, Items.make("IRON_PICKAXE", "<red><bold>Pekerjaan",
                "<gray>Pilih job dan dapat uang", "<gray>dari aktivitasmu.", "", "<yellow>Klik untuk membuka"));

        inv.setItem(20, Items.make("BOOK", "<yellow><bold>Riwayat Transaksi",
                "<gray>Lihat transaksi terakhirmu.", "", "<yellow>Klik untuk membuka"));
        inv.setItem(22, Items.make(d.acceptPay ? "LIME_DYE" : "RED_DYE", "<white><bold>Terima Pembayaran: "
                        + (d.acceptPay ? "<green>ON" : "<red>OFF"),
                "<gray>Atur apakah pemain lain", "<gray>boleh mengirim uang ke kamu.", "", "<yellow>Klik untuk mengubah"));
        inv.setItem(24, Items.make("PAPER", "<green><bold>Banknote",
                "<gray>Ubah saldo jadi kertas yang", "<gray>bisa diberikan ke pemain lain.", "",
                "<yellow>/note [jumlah]"));

        inv.setItem(28, Items.make("NETHER_STAR", "<light_purple><bold>Top Terkaya",
                "<gray>Lihat 10 pemain terkaya.", "", "<yellow>Klik untuk membuka"));
        inv.setItem(30, Items.make("PAPER", "<white><bold>Kirim Uang",
                "<gray>Kirim uang ke pemain online.", "", "<yellow>Klik untuk membuka"));
        inv.setItem(32, Items.make("CHEST", "<gold><bold>Jual Semua",
                "<gray>Jual semua item yang bisa", "<gray>dijual dari inventory.", "", "<yellow>Klik untuk menjual"));
        inv.setItem(34, Items.make("BOOK", "<aqua><bold>Daftar Perintah",
                "<yellow>/menu <gray>- menu utama",
                "<yellow>/bal [pemain] <gray>- cek saldo",
                "<yellow>/pay <gray>- kirim uang",
                "<yellow>/shop [kategori] <gray>- toko",
                "<yellow>/buy [item] [jumlah]",
                "<yellow>/sell [hand|all|item] <gray>- jual",
                "<yellow>/worth <gray>- harga item di tangan",
                "<yellow>/bank [deposit|withdraw]",
                "<yellow>/daily <gray>- hadiah harian",
                "<yellow>/jobs [join|leave|info]",
                "<yellow>/note [jumlah] <gray>- banknote",
                "<yellow>/history <gray>- riwayat",
                "<yellow>/paytoggle <gray>- tolak/terima uang",
                "<yellow>/baltop <gray>- top terkaya"));
        inv.setItem(49, Items.make("BARRIER", "<red>Tutup"));
    }

    @Override
    void click(InventoryClickEvent e) {
        PData d = p.data.get(pl.getUniqueId());
        switch (e.getSlot()) {
            case 10:
                new ShopMenu(p, pl).open();
                break;
            case 12:
                new BankGui(p, pl).open();
                break;
            case 14:
                p.daily(pl);
                draw();
                break;
            case 16:
                new JobsGui(p, pl).open();
                break;
            case 20:
                new HistoryGui(p, pl).open();
                break;
            case 22:
                d.acceptPay = !d.acceptPay;
                draw();
                break;
            case 28:
                new TopGui(p, pl).open();
                break;
            case 30:
                new PaySelect(p, pl).open();
                break;
            case 32:
                p.sellAll(pl);
                draw();
                break;
            case 49:
                pl.closeInventory();
                return;
            default:
                return;
        }
        sound(Compat.S_CLICK, 1f);
    }
}
