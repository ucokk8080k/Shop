package id.pahri.ecomenu;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

final class ShopItems extends Gui {
    private final List<Map.Entry<String, double[]>> list;
    private int page;

    ShopItems(EcoMenu p, Player pl, EcoMenu.Cat cat, int page) {
        super(p, pl, 6, cat.name + " <dark_gray>- Toko");
        this.list = new ArrayList<Map.Entry<String, double[]>>(cat.items.entrySet());
        this.page = page;
    }

    private int pages() {
        return Math.max(1, (list.size() + 44) / 45);
    }

    @Override
    void draw() {
        inv.clear();
        ItemStack g = Items.make("GRAY_STAINED_GLASS_PANE", " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, g);

        double mult = p.sellMult(pl);
        int start = page * 45;
        for (int i = 0; i < 45 && start + i < list.size(); i++) {
            Map.Entry<String, double[]> en = list.get(start + i);
            double[] pr = en.getValue();
            ItemStack it = Compat.stack(en.getKey(), 1);
            if (it == null) continue;
            List<String> lore = new ArrayList<String>();
            lore.add(pr[0] >= 0 ? "<gray>Beli: <green>" + p.fmt(pr[0]) : "<gray>Beli: <red>tidak tersedia");
            lore.add(pr[1] >= 0 ? "<gray>Jual: <gold>" + p.fmt(pr[1] * mult) + (mult > 1 ? " <gray>(x" + mult + ")" : "")
                    : "<gray>Jual: <red>tidak bisa");
            lore.add("");
            lore.add("<yellow>Klik kiri <gray>» beli 1");
            lore.add("<yellow>Shift+kiri <gray>» beli 1 stack");
            lore.add("<yellow>Klik kanan <gray>» jual 1");
            lore.add("<yellow>Shift+kanan <gray>» jual semua");
            ItemMeta mt = it.getItemMeta();
            mt.setLore(Items.lore(lore));
            it.setItemMeta(mt);
            inv.setItem(i, it);
        }

        if (page > 0) inv.setItem(45, Items.make("ARROW", "<yellow>« Sebelumnya"));
        inv.setItem(47, Items.make("CHEST", "<gold>Jual Semua", "<gray>Jual semua item yang bisa dijual."));
        inv.setItem(49, Items.make("BARRIER", "<red>« Kategori"));
        inv.setItem(51, wallet());
        if (page + 1 < pages()) inv.setItem(53, Items.make("ARROW", "<yellow>Berikutnya »"));
        inv.setItem(52, Items.make("PAPER", "<gray>Halaman " + (page + 1) + "/" + pages()));
    }

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getSlot();
        if (s < 45) {
            int idx = page * 45 + s;
            if (idx >= list.size()) return;
            String key = list.get(idx).getKey();
            ClickType ct = e.getClick();
            boolean ok = false;
            if (ct == ClickType.LEFT) {
                ok = p.buy(pl, key, 1);
            } else if (ct == ClickType.SHIFT_LEFT) {
                ItemStack st = Compat.stack(key, 1);
                ok = p.buy(pl, key, st == null ? 1 : st.getMaxStackSize());
            } else if (ct == ClickType.RIGHT) {
                ok = p.sellKey(pl, key, 1) > 0;
            } else if (ct == ClickType.SHIFT_RIGHT) {
                ok = p.sellKey(pl, key, Integer.MAX_VALUE) > 0;
            }
            if (ok) sound(Compat.S_XP, 1.2f);
            draw();
            return;
        }
        switch (s) {
            case 45:
                if (page > 0) {
                    page--;
                    draw();
                }
                break;
            case 47:
                p.sellAll(pl);
                draw();
                break;
            case 49:
                new ShopMenu(p, pl).open();
                break;
            case 53:
                if (page + 1 < pages()) {
                    page++;
                    draw();
                }
                break;
            default:
                break;
        }
    }
}
