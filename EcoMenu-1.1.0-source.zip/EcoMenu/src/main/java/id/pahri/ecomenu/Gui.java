package id.pahri.ecomenu;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

abstract class Gui implements InventoryHolder {
    final EcoMenu p;
    final Player pl;
    final Inventory inv;
    final int rows;

    Gui(EcoMenu p, Player pl, int rows, String title) {
        this.p = p;
        this.pl = pl;
        this.rows = rows;
        String t = Txt.c(title);
        if (Compat.MINOR < 14 && t.length() > 32) {
            t = t.substring(0, 32);
            if (t.endsWith("§")) t = t.substring(0, 31);
        }
        this.inv = Bukkit.createInventory(this, rows * 9, t);
    }

    static String title(String t) {
        return "<gold><bold>" + t;
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }

    abstract void draw();

    abstract void click(InventoryClickEvent e);

    void open() {
        draw();
        pl.openInventory(inv);
    }

    void sound(String[] s, float pitch) {
        p.snd(pl, s, pitch);
    }

    /** Isi semua slot dengan kaca abu, tepi dengan kaca oranye. */
    void fill() {
        inv.clear();
        ItemStack g = Items.make("GRAY_STAINED_GLASS_PANE", " ");
        ItemStack b = Items.make("ORANGE_STAINED_GLASS_PANE", " ");
        for (int i = 0; i < inv.getSize(); i++) {
            int r = i / 9, c = i % 9;
            inv.setItem(i, (r == 0 || r == rows - 1 || c == 0 || c == 8) ? b : g);
        }
    }

    ItemStack back() {
        return Items.make("ARROW", "<yellow>« Kembali", "<gray>Kembali ke menu utama");
    }

    ItemStack wallet() {
        PData d = p.data.get(pl.getUniqueId());
        return Items.make("GOLD_INGOT", "<yellow><bold>Saldo Kamu",
                "<gray>Dompet: <green>" + p.fmt(d.bal), "<gray>Bank: <aqua>" + p.fmt(d.bank));
    }
}
