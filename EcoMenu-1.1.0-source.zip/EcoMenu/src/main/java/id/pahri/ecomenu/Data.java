package id.pahri.ecomenu;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

final class PData {
    String name = "?";
    double bal, bank;
    long lastDaily;
    int streak;
    String job = "";
    boolean acceptPay = true;
    final Map<String, Integer> xp = new HashMap<String, Integer>();
    /** Format: "waktuMillis|teks". Terbaru di indeks 0. */
    final List<String> history = new ArrayList<String>();
}

final class Data {
    final EcoMenu p;
    final ConcurrentHashMap<UUID, PData> map = new ConcurrentHashMap<UUID, PData>();
    /** Banknote yang beredar: id -> nilai. Dihapus saat ditukar (anti-duplikasi). */
    final Map<String, Double> notes = new ConcurrentHashMap<String, Double>();
    private final File file;

    Data(EcoMenu p) {
        this.p = p;
        this.file = new File(p.getDataFolder(), "data.yml");
    }

    PData get(UUID u) {
        PData d = map.get(u);
        if (d == null) {
            d = new PData();
            d.bal = p.getConfig().getDouble("start-balance", 1000);
            PData old = map.putIfAbsent(u, d);
            if (old != null) d = old;
        }
        return d;
    }

    void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection pl = y.getConfigurationSection("players");
        if (pl != null) readPlayers(pl);
        readPlayers(y); // format lama (UUID langsung di root)
        ConfigurationSection nt = y.getConfigurationSection("notes");
        if (nt != null) for (String k : nt.getKeys(false)) notes.put(k, nt.getDouble(k));
    }

    private void readPlayers(ConfigurationSection root) {
        for (String k : root.getKeys(false)) {
            UUID u;
            try {
                u = UUID.fromString(k);
            } catch (IllegalArgumentException ex) {
                continue;
            }
            ConfigurationSection s = root.getConfigurationSection(k);
            if (s == null) continue;
            PData d = new PData();
            d.name = s.getString("name", "?");
            d.bal = s.getDouble("bal");
            d.bank = s.getDouble("bank");
            d.lastDaily = s.getLong("last-daily");
            d.streak = s.getInt("streak");
            d.job = s.getString("job", "");
            d.acceptPay = s.getBoolean("accept-pay", true);
            ConfigurationSection x = s.getConfigurationSection("xp");
            if (x != null) for (String j : x.getKeys(false)) d.xp.put(j, x.getInt(j));
            d.history.addAll(s.getStringList("history"));
            map.put(u, d);
        }
    }

    /** Bangun isi YAML di thread utama, tulis ke disk (opsional async). */
    void save(boolean async) {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, PData> e : map.entrySet()) {
            String k = "players." + e.getKey();
            PData d = e.getValue();
            y.set(k + ".name", d.name);
            y.set(k + ".bal", d.bal);
            y.set(k + ".bank", d.bank);
            y.set(k + ".last-daily", d.lastDaily);
            y.set(k + ".streak", d.streak);
            y.set(k + ".job", d.job);
            y.set(k + ".accept-pay", d.acceptPay);
            for (Map.Entry<String, Integer> x : d.xp.entrySet()) y.set(k + ".xp." + x.getKey(), x.getValue());
            if (!d.history.isEmpty()) y.set(k + ".history", new ArrayList<String>(d.history));
        }
        for (Map.Entry<String, Double> n : notes.entrySet()) y.set("notes." + n.getKey(), n.getValue());
        final String text = y.saveToString();
        if (async) {
            Bukkit.getScheduler().runTaskAsynchronously(p, new Runnable() {
                @Override
                public void run() {
                    write(text);
                }
            });
        } else {
            write(text);
        }
    }

    private synchronized void write(String text) {
        try {
            p.getDataFolder().mkdirs();
            File tmp = new File(p.getDataFolder(), "data.yml.tmp");
            Files.write(tmp.toPath(), text.getBytes(StandardCharsets.UTF_8));
            try {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            p.getLogger().severe("Gagal menyimpan data.yml: " + ex.getMessage());
        }
    }
}
