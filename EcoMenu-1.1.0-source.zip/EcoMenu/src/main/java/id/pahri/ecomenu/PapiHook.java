package id.pahri.ecomenu;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Placeholder: %ecomenu_balance%, _bank, _total, _job, _job_level, _streak, _daily_ready, _rank, _top_N_name, _top_N_balance (+ _formatted). */
final class PapiHook extends PlaceholderExpansion {
    private final EcoMenu p;

    PapiHook(EcoMenu p) {
        this.p = p;
    }

    @Override
    public String getIdentifier() {
        return "ecomenu";
    }

    @Override
    public String getAuthor() {
        return "Pahri";
    }

    @Override
    public String getVersion() {
        return p.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer pl, String id) {
        id = id.toLowerCase();
        if (id.startsWith("top_")) {
            String[] a = id.split("_");
            if (a.length < 3) return "";
            int n;
            try {
                n = Integer.parseInt(a[1]);
            } catch (NumberFormatException ex) {
                return "";
            }
            List<Map.Entry<UUID, PData>> top = p.top();
            if (n < 1 || n > top.size()) return a[2].equals("name") ? "-" : "0";
            PData d = top.get(n - 1).getValue();
            double tot = d.bal + d.bank;
            if (a[2].equals("name")) return d.name;
            if (id.endsWith("formatted")) return p.fmt(tot);
            return String.valueOf(p.round(tot));
        }
        if (pl == null) return "";
        PData d = p.data.get(pl.getUniqueId());
        switch (id) {
            case "balance":
                return String.valueOf(p.round(d.bal));
            case "balance_formatted":
                return p.fmt(d.bal);
            case "bank":
                return String.valueOf(p.round(d.bank));
            case "bank_formatted":
                return p.fmt(d.bank);
            case "total":
                return String.valueOf(p.round(d.bal + d.bank));
            case "total_formatted":
                return p.fmt(d.bal + d.bank);
            case "job": {
                EcoMenu.Job j = p.jobs.get(d.job);
                return j == null ? "-" : Txt.strip(Txt.c(j.name));
            }
            case "job_level":
                return d.job.isEmpty() ? "0" : String.valueOf(p.level(d, d.job));
            case "streak":
                return String.valueOf(d.streak);
            case "daily_ready":
                return String.valueOf(p.dailyRemaining(d) <= 0);
            case "rank": {
                List<Map.Entry<UUID, PData>> top = p.top();
                for (int i = 0; i < top.size(); i++) if (top.get(i).getKey().equals(pl.getUniqueId())) return String.valueOf(i + 1);
                return "-";
            }
            default:
                return null;
        }
    }
}
