package id.pahri.ecomenu;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

final class HistoryGui extends Gui {
    HistoryGui(EcoMenu p, Player pl) {
        super(p, pl, 4, title("Riwayat Transaksi"));
    }

    private int slot(int i) {
        return 10 + (i / 7) * 9 + i % 7;
    }

    @Override
    void draw() {
        fill();
        List<String> h = p.data.get(pl.getUniqueId()).history;
        for (int i = 0; i < h.size() && i < 14; i++) {
            String e = h.get(i);
            int bar = e.indexOf('|');
            long t = 0;
            String text = e;
            if (bar > 0) {
                try {
                    t = Long.parseLong(e.substring(0, bar));
                    text = e.substring(bar + 1);
                } catch (NumberFormatException ignored) {
                }
            }
            inv.setItem(slot(i), Items.make("PAPER", text, "<dark_gray>" + (t > 0 ? p.ago(t) : "")));
        }
        if (h.isEmpty()) inv.setItem(22, Items.make("BARRIER", "<red>Belum ada transaksi"));
        inv.setItem(4, wallet());
        inv.setItem(31, back());
    }

    @Override
    void click(InventoryClickEvent e) {
        if (e.getSlot() == 31) new MainMenu(p, pl).open();
    }
}
