package id.pahri.ecomenu;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.ServicePriority;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.UUID;

/**
 * Mendaftarkan EcoMenu sebagai provider ekonomi Vault TANPA dependency compile ke Vault:
 * interface Economy dibuat lewat java.lang.reflect.Proxy, jadi jar tetap jalan walau Vault tidak ada.
 */
final class VaultHook {
    private VaultHook() {
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static void hook(final EcoMenu p) throws Exception {
        Plugin vp = Bukkit.getPluginManager().getPlugin("Vault");
        ClassLoader cl = vp.getClass().getClassLoader();
        final Class<?> eco = Class.forName("net.milkbowl.vault.economy.Economy", true, cl);
        Class<?> resp = Class.forName("net.milkbowl.vault.economy.EconomyResponse", true, cl);
        Class<?> rtype = Class.forName("net.milkbowl.vault.economy.EconomyResponse$ResponseType", true, cl);
        final Constructor<?> ctor = resp.getConstructor(double.class, double.class, rtype, String.class);
        Object ok = null, fail = null, ni = null;
        for (Object o : rtype.getEnumConstants()) {
            String n = ((Enum) o).name();
            if (n.equals("SUCCESS")) ok = o;
            else if (n.equals("FAILURE")) fail = o;
            else if (n.equals("NOT_IMPLEMENTED")) ni = o;
        }
        final Object OK = ok, FAIL = fail, NI = ni;

        InvocationHandler h = new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method m, Object[] a) throws Throwable {
                Object[] args = a == null ? new Object[0] : a;
                String n = m.getName();
                switch (n) {
                    case "hashCode":
                        return System.identityHashCode(proxy);
                    case "equals":
                        return proxy == args[0];
                    case "toString":
                        return "EcoMenuEconomy";
                    case "isEnabled":
                    case "hasAccount":
                    case "createPlayerAccount":
                        return true;
                    case "getName":
                        return "EcoMenu";
                    case "hasBankSupport":
                        return false;
                    case "fractionalDigits":
                        return 2;
                    case "format":
                        return p.fmt((Double) args[0]);
                    case "currencyNamePlural":
                        return p.getConfig().getString("currency-name-plural", "Dollar");
                    case "currencyNameSingular":
                        return p.getConfig().getString("currency-name", "Dollar");
                    case "getBanks":
                        return new ArrayList<String>();
                    case "getBalance":
                        return p.data.get(uuid(p, args[0])).bal;
                    case "has":
                        return p.data.get(uuid(p, args[0])).bal >= amount(args);
                    case "withdrawPlayer": {
                        double amt = amount(args);
                        UUID u = uuid(p, args[0]);
                        if (!(amt >= 0)) return ctor.newInstance(0.0, p.data.get(u).bal, FAIL, "Jumlah negatif");
                        if (!p.take(u, amt)) return ctor.newInstance(0.0, p.data.get(u).bal, FAIL, "Saldo tidak cukup");
                        return ctor.newInstance(amt, p.data.get(u).bal, OK, null);
                    }
                    case "depositPlayer": {
                        double amt = amount(args);
                        UUID u = uuid(p, args[0]);
                        if (!(amt >= 0)) return ctor.newInstance(0.0, p.data.get(u).bal, FAIL, "Jumlah negatif");
                        p.give(u, amt);
                        return ctor.newInstance(amt, p.data.get(u).bal, OK, null);
                    }
                    default:
                        return ctor.newInstance(0.0, 0.0, NI, "EcoMenu tidak mendukung bank Vault");
                }
            }
        };
        Object proxy = Proxy.newProxyInstance(cl, new Class<?>[]{eco}, h);
        Bukkit.getServicesManager().register((Class) eco, proxy, p, ServicePriority.Highest);
    }

    private static double amount(Object[] args) {
        for (Object o : args) if (o instanceof Double) return (Double) o;
        return 0;
    }

    @SuppressWarnings("deprecation")
    private static UUID uuid(EcoMenu p, Object o) {
        if (o instanceof OfflinePlayer) return ((OfflinePlayer) o).getUniqueId();
        String name = String.valueOf(o);
        UUID u = p.find(name);
        return u != null ? u : Bukkit.getOfflinePlayer(name).getUniqueId();
    }
}
