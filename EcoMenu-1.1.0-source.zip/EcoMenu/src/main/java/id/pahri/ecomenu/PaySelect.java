package id.pahri.ecomenu;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

final class PaySelect extends Gui {
    private final List<Player> list = new ArrayList<Player>();

    PaySelect(EcoMenu p, Player pl) {
        super(p, pl, 6, title("Kirim Uang"));
    }

    @Override
    void draw() {
        inv.clear();
        list.clear();
        ItemStack g = Items.make("GRAY_STAINED_GLASS_PANE", " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, g);
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.equals(pl) || list.size() >= 45) continue;
            list.add(o);
        }
        for (int i = 0; i < list.size(); i++) {
            Player o = list.get(i);
            inv.setItem(i, Items.head(o.getUniqueId(), o.getName(), "<yellow>" + o.getName(), "<gray>Klik untuk memilih"));
        }
        if (list.isEmpty()) inv.setItem(22, Items.make("BARRIER", "<red>Tidak ada pemain lain online"));
        inv.setItem(49, back());
    }

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getSlot();
        if (s == 49) {
            new MainMenu(p, pl).open();
            return;
        }
        if (s < 45 && s < list.size()) {
            Player t = list.get(s);
            if (!t.isOnline()) {
                draw();
                return;
            }
            new PayAmount(p, pl, t.getUniqueId(), t.getName()).open();
        }
    }
}
