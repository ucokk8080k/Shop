package id.pahri.ecomenu;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class JobsGui extends Gui {
    private final List<EcoMenu.Job> list = new ArrayList<EcoMenu.Job>();

    JobsGui(EcoMenu p, Player pl) {
        super(p, pl, 5, title("Pekerjaan"));
    }

    private int slot(int i) {
        return 10 + (i / 7) * 9 + i % 7;
    }

    @Override
    void draw() {
        fill();
        list.clear();
        list.addAll(p.jobs.values());
        PData d = p.data.get(pl.getUniqueId());
        int per = Math.max(1, p.getConfig().getInt("job-xp-per-level", 150));

        for (int i = 0; i < list.size() && i < 14; i++) {
            EcoMenu.Job j = list.get(i);
            boolean active = j.id.equals(d.job);
            int lv = p.level(d, j.id);
            int xp = d.xp.getOrDefault(j.id, 0);

            List<String> lore = new ArrayList<String>();
            lore.add(j.desc);
            lore.add("");
            lore.add("<gray>Level: <yellow>" + lv + " <dark_gray>(" + (xp % per) + "/" + per + " xp)");
            lore.add("<gray>Bonus gaji: <green>+" + (int) ((lv - 1) * p.bonusPerLevel()) + "%");
            lore.add("");
            lore.add("<gray>Bayaran:");
            int n = 0;
            for (Map.Entry<String, Double> en : j.pay.entrySet()) {
                if (n++ >= 6) {
                    lore.add("<dark_gray>  ...dan lainnya");
                    break;
                }
                lore.add("<dark_gray>  - <white>" + en.getKey().toLowerCase(Locale.ROOT).replace('_', ' ')
                        + "<gray>: <green>" + p.fmt(en.getValue()));
            }
            lore.add("");
            lore.add(active ? "<green>✔ Pekerjaan aktif" : "<yellow>Klik untuk memilih");

            ItemStack it = Items.make(j.icon, j.name, lore);
            inv.setItem(slot(i), active ? Items.glow(it) : it);
        }
        inv.setItem(38, Items.make("BARRIER", "<red>Keluar dari Pekerjaan",
                "<gray>Berhenti dari job saat ini.", "", "<yellow>Klik untuk keluar"));
        inv.setItem(40, back());
    }

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getSlot();
        if (s == 40) {
            new MainMenu(p, pl).open();
            return;
        }
        if (s == 38) {
            p.leaveJob(pl);
            sound(Compat.S_CLICK, 1f);
            draw();
            return;
        }
        for (int i = 0; i < list.size() && i < 14; i++) {
            if (slot(i) == s) {
                p.joinJob(pl, list.get(i).id);
                draw();
                return;
            }
        }
    }
}
