package id.pahri.ecomenu;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

final class Cmds implements CommandExecutor, TabCompleter {
    private final EcoMenu p;

    Cmds(EcoMenu p) {
        this.p = p;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String n = c.getName().toLowerCase(Locale.ROOT);
        if (n.equals("eco")) return eco(s, a);
        if (!(s instanceof Player)) {
            s.sendMessage("Perintah ini hanya untuk pemain.");
            return true;
        }
        Player pl = (Player) s;
        switch (n) {
            case "menu":
                new MainMenu(p, pl).open();
                break;
            case "balance":
                bal(pl, a);
                break;
            case "pay":
                pay(pl, a);
                break;
            case "baltop":
                new TopGui(p, pl).open();
                break;
            case "shop":
                shop(pl, a);
                break;
            case "sell":
                sell(pl, a);
                break;
            case "buy":
                buy(pl, a);
                break;
            case "worth":
                worth(pl);
                break;
            case "bank":
                bank(pl, a);
                break;
            case "daily":
                p.daily(pl);
                break;
            case "jobs":
                jobs(pl, a);
                break;
            case "history":
                new HistoryGui(p, pl).open();
                break;
            case "note":
                if (a.length < 1) {
                    p.msg(pl, "<yellow>Pakai: /note [jumlah]");
                } else {
                    double v = p.parseAmount(a[0]);
                    if (Double.isNaN(v)) p.msg(pl, "<red>Jumlah tidak valid.");
                    else p.createNote(pl, v);
                }
                break;
            case "paytoggle":
                PData d = p.data.get(pl.getUniqueId());
                d.acceptPay = !d.acceptPay;
                p.msg(pl, d.acceptPay ? "<green>Kamu sekarang menerima pembayaran." : "<yellow>Kamu sekarang menolak pembayaran.");
                break;
            default:
                break;
        }
        return true;
    }

    private void bal(Player pl, String[] a) {
        UUID u = pl.getUniqueId();
        if (a.length > 0) {
            u = p.find(a[0]);
            if (u == null) {
                p.msg(pl, "<red>Pemain tidak ditemukan.");
                return;
            }
        }
        PData d = p.data.get(u);
        String who = u.equals(pl.getUniqueId()) ? "Kamu" : d.name;
        p.msg(pl, "<yellow>" + who + "</yellow> <gray>» Dompet: <green>" + p.fmt(d.bal)
                + " <gray>| Bank: <aqua>" + p.fmt(d.bank));
    }

    private void pay(Player pl, String[] a) {
        if (a.length < 2) {
            p.msg(pl, "<yellow>Pakai: /pay [pemain] [jumlah]");
            return;
        }
        UUID u = p.find(a[0]);
        if (u == null) {
            p.msg(pl, "<red>Pemain tidak ditemukan.");
            return;
        }
        double v = p.parseAmount(a[1]);
        if (Double.isNaN(v)) {
            p.msg(pl, "<red>Jumlah tidak valid.");
            return;
        }
        p.transfer(pl, u, p.data.get(u).name, v);
    }

    private void shop(Player pl, String[] a) {
        if (a.length > 0) {
            for (EcoMenu.Cat cat : p.shop.values()) {
                if (cat.id.equalsIgnoreCase(a[0])) {
                    new ShopItems(p, pl, cat, 0).open();
                    return;
                }
            }
            p.msg(pl, "<red>Kategori tidak ditemukan.");
            return;
        }
        new ShopMenu(p, pl).open();
    }

    private String keyArg(String s) {
        return s.toUpperCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
    }

    private void sell(Player pl, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("all")) {
            p.sellAll(pl);
            return;
        }
        if (a[0].equalsIgnoreCase("hand")) {
            p.sellHand(pl);
            return;
        }
        String key = keyArg(a[0]);
        if (!p.prices.containsKey(key)) {
            p.msg(pl, "<red>Item tidak dikenal. Pakai: /sell [hand|all|item] [jumlah]");
            return;
        }
        int amt = Integer.MAX_VALUE;
        if (a.length > 1 && !a[1].equalsIgnoreCase("all")) {
            try {
                amt = Integer.parseInt(a[1]);
            } catch (NumberFormatException ex) {
                p.msg(pl, "<red>Jumlah tidak valid.");
                return;
            }
            if (amt < 1) {
                p.msg(pl, "<red>Jumlah tidak valid.");
                return;
            }
        }
        p.sellKey(pl, key, amt);
    }

    private void buy(Player pl, String[] a) {
        if (a.length < 1) {
            p.msg(pl, "<yellow>Pakai: /buy [item] [jumlah]");
            return;
        }
        String key = keyArg(a[0]);
        if (!p.prices.containsKey(key)) {
            p.msg(pl, "<red>Item tidak dikenal.");
            return;
        }
        int amt = 1;
        if (a.length > 1) {
            try {
                amt = Integer.parseInt(a[1]);
            } catch (NumberFormatException ex) {
                p.msg(pl, "<red>Jumlah tidak valid.");
                return;
            }
        }
        if (amt < 1 || amt > 2304) {
            p.msg(pl, "<red>Jumlah harus 1 sampai 2304.");
            return;
        }
        p.buy(pl, key, amt);
    }

    private void worth(Player pl) {
        ItemStack h = Compat.hand(pl);
        if (h == null || h.getType() == org.bukkit.Material.AIR) {
            p.msg(pl, "<red>Pegang item yang mau dicek harganya.");
            return;
        }
        String key = Compat.keyOf(h);
        double[] pr = p.prices.get(key);
        if (pr == null) {
            p.msg(pl, "<yellow>" + p.nice(key) + "</yellow> <gray>tidak ada di toko.");
            return;
        }
        double mult = p.sellMult(pl);
        p.msg(pl, "<yellow>" + p.nice(key) + "</yellow> <gray>» Beli: "
                + (pr[0] >= 0 ? "<green>" + p.fmt(pr[0]) : "<red>-")
                + " <gray>| Jual: " + (pr[1] >= 0 ? "<gold>" + p.fmt(pr[1] * mult) : "<red>-")
                + (pr[1] >= 0 && h.getAmount() > 1 ? " <gray>(stack: <gold>" + p.fmt(pr[1] * mult * h.getAmount()) + "<gray>)" : ""));
    }

    private void bank(Player pl, String[] a) {
        if (a.length == 0) {
            new BankGui(p, pl).open();
            return;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        PData d = p.data.get(pl.getUniqueId());
        if (sub.equals("balance") || sub.equals("saldo")) {
            p.msg(pl, "<gray>Bank: <aqua>" + p.fmt(d.bank) + " <gray>| Dompet: <green>" + p.fmt(d.bal));
            return;
        }
        boolean dep = sub.equals("deposit") || sub.equals("setor");
        boolean wd = sub.equals("withdraw") || sub.equals("tarik");
        if (!dep && !wd || a.length < 2) {
            p.msg(pl, "<yellow>Pakai: /bank [deposit|withdraw|balance] [jumlah|all]");
            return;
        }
        double v = a[1].equalsIgnoreCase("all") ? -1 : p.parseAmount(a[1]);
        if (Double.isNaN(v) || (v == 0)) {
            p.msg(pl, "<red>Jumlah tidak valid.");
            return;
        }
        p.bankMove(pl, dep, v);
    }

    private void jobs(Player pl, String[] a) {
        if (a.length == 0) {
            new JobsGui(p, pl).open();
            return;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (sub.equals("join") && a.length > 1) {
            p.joinJob(pl, a[1]);
        } else if (sub.equals("leave")) {
            p.leaveJob(pl);
        } else if (sub.equals("info")) {
            PData d = p.data.get(pl.getUniqueId());
            EcoMenu.Job j = p.jobs.get(d.job);
            if (j == null) {
                p.msg(pl, "<yellow>Kamu belum punya pekerjaan. Pakai <gold>/jobs join [nama]</gold>.");
                return;
            }
            int lv = p.level(d, j.id);
            p.msg(pl, "<gray>Job: " + j.name + " <gray>| Level: <yellow>" + lv + " <gray>| XP: <yellow>"
                    + d.xp.getOrDefault(j.id, 0) + " <gray>| Bonus: <green>+" + (int) ((lv - 1) * p.bonusPerLevel()) + "%");
        } else {
            p.msg(pl, "<yellow>Pakai: /jobs [join <nama>|leave|info]");
        }
    }

    private boolean eco(CommandSender s, String[] a) {
        if (!s.hasPermission("ecomenu.admin")) {
            p.msg(s, "<red>Kamu tidak punya izin.");
            return true;
        }
        if (a.length >= 1 && a[0].equalsIgnoreCase("reload")) {
            p.loadAll();
            p.msg(s, "<green>Config & toko dimuat ulang.");
            return true;
        }
        if (a.length >= 2 && a[0].equalsIgnoreCase("giveall")) {
            double v = p.parseAmount(a[1]);
            if (Double.isNaN(v) || v <= 0) {
                p.msg(s, "<red>Jumlah tidak valid.");
                return true;
            }
            int n = 0;
            for (Player o : Bukkit.getOnlinePlayers()) {
                p.give(o.getUniqueId(), v);
                p.log(o.getUniqueId(), "<green>+" + p.fmt(v) + " <gray>hadiah admin");
                p.msg(o, "<green>Kamu mendapat <yellow>" + p.fmt(v) + "</yellow> dari admin.");
                n++;
            }
            p.msg(s, "<green>Memberi <yellow>" + p.fmt(v) + "</yellow> ke <white>" + n + "</white> pemain online.");
            return true;
        }
        if (a.length < 2) {
            p.msg(s, "<yellow>Pakai: /eco [give|take|set|reset|check|giveall|reload] [pemain] [jumlah]");
            return true;
        }
        UUID u = p.find(a[1]);
        if (u == null) {
            p.msg(s, "<red>Pemain tidak ditemukan.");
            return true;
        }
        PData d = p.data.get(u);
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (sub.equals("check")) {
            p.msg(s, "<white>" + d.name + "</white> <gray>» Dompet: <green>" + p.fmt(d.bal) + " <gray>| Bank: <aqua>"
                    + p.fmt(d.bank) + " <gray>| Job: <white>" + (d.job.isEmpty() ? "-" : d.job));
            return true;
        }
        if (sub.equals("reset")) {
            d.bal = p.getConfig().getDouble("start-balance", 1000);
            d.bank = 0;
            p.msg(s, "<green>Saldo <white>" + d.name + "</white> direset.");
            return true;
        }
        if (a.length < 3) {
            p.msg(s, "<yellow>Pakai: /eco [give|take|set] [pemain] [jumlah]");
            return true;
        }
        double v = p.parseAmount(a[2]);
        if (Double.isNaN(v) || v < 0 || v > 1e15) {
            p.msg(s, "<red>Jumlah tidak valid.");
            return true;
        }
        if (sub.equals("give")) {
            d.bal = p.round(d.bal + v);
            p.log(u, "<green>+" + p.fmt(v) + " <gray>diberi admin");
        } else if (sub.equals("take")) {
            d.bal = p.round(Math.max(0, d.bal - v));
            p.log(u, "<red>-" + p.fmt(v) + " <gray>diambil admin");
        } else if (sub.equals("set")) {
            d.bal = p.round(v);
            p.log(u, "<yellow>Saldo diatur admin: " + p.fmt(v));
        } else {
            p.msg(s, "<yellow>Pakai: /eco [give|take|set|reset|check|giveall|reload] [pemain] [jumlah]");
            return true;
        }
        p.msg(s, "<green>Saldo <white>" + d.name + "</white> sekarang <yellow>" + p.fmt(d.bal) + "</yellow>.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        String n = c.getName().toLowerCase(Locale.ROOT);
        if (n.equals("eco")) {
            if (a.length == 1) return filter(Arrays.asList("give", "take", "set", "reset", "check", "giveall", "reload"), a[0]);
            if (a.length == 2 && !a[0].equalsIgnoreCase("reload") && !a[0].equalsIgnoreCase("giveall")) return players(a[1]);
        } else if ((n.equals("pay") || n.equals("balance")) && a.length == 1) {
            return players(a[0]);
        } else if (n.equals("sell") && a.length == 1) {
            List<String> l = new ArrayList<String>(Arrays.asList("hand", "all"));
            l.addAll(items());
            return filter(l, a[0]);
        } else if (n.equals("buy") && a.length == 1) {
            return filter(items(), a[0]);
        } else if (n.equals("shop") && a.length == 1) {
            return filter(new ArrayList<String>(p.shop.keySet()), a[0]);
        } else if (n.equals("bank") && a.length == 1) {
            return filter(Arrays.asList("deposit", "withdraw", "balance"), a[0]);
        } else if (n.equals("bank") && a.length == 2) {
            return filter(Arrays.asList("all"), a[1]);
        } else if (n.equals("jobs") && a.length == 1) {
            return filter(Arrays.asList("join", "leave", "info"), a[0]);
        } else if (n.equals("jobs") && a.length == 2 && a[0].equalsIgnoreCase("join")) {
            return filter(new ArrayList<String>(p.jobs.keySet()), a[1]);
        }
        return new ArrayList<String>();
    }

    private List<String> items() {
        List<String> l = new ArrayList<String>();
        for (String k : p.prices.keySet()) l.add(k.toLowerCase(Locale.ROOT));
        return l;
    }

    private List<String> filter(List<String> l, String pre) {
        List<String> r = new ArrayList<String>();
        String lp = pre.toLowerCase(Locale.ROOT);
        for (String x : l) if (x.startsWith(lp)) r.add(x);
        return r;
    }

    private List<String> players(String pre) {
        List<String> r = new ArrayList<String>();
        for (Player o : Bukkit.getOnlinePlayers())
            if (o.getName().toLowerCase(Locale.ROOT).startsWith(pre.toLowerCase(Locale.ROOT))) r.add(o.getName());
        return r;
    }
}
