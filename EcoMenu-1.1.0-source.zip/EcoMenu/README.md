# EcoMenu 1.1.0
Plugin economy lengkap dengan GUI lewat `/menu`. **Satu jar untuk Minecraft 1.8 sampai versi terbaru** (Spigot / Paper / Purpur, Java 8+).

## Fitur
- Dompet, bank (bunga otomatis), hadiah harian + streak, `/pay`, `/baltop`
- Toko GUI (8 kategori), `/buy`, `/sell [hand|all|item]`, `/worth`
- Job: Penambang, Penebang, Petani, Pemburu, **Nelayan**, **Penggali** (level + bonus gaji, anti-exploit blok buatan pemain)
- **Vault**: otomatis terdaftar sebagai provider ekonomi kalau Vault terpasang (plugin lain bisa pakai uang EcoMenu)
- **PlaceholderAPI**: `%ecomenu_balance%`, `_balance_formatted`, `_bank`, `_total`, `_job`, `_job_level`, `_streak`, `_daily_ready`, `_rank`, `_top_1_name`, `_top_1_balance_formatted` (1-10)
- **Banknote** (`/note <jumlah>`): saldo jadi kertas, klik kanan untuk menukar (anti-duplikasi)
- **Riwayat transaksi** (`/history`)
- Pajak `/pay`, `/paytoggle` (tolak pembayaran), jumlah singkat `1k`, `2.5m`
- Pengali harga jual per permission (VIP/MVP, atur di config)
- Gaji main online, penalti uang saat mati (opsional)
- Admin: `/eco give|take|set|reset|check|giveall|reload`
- Warna MiniMessage (`<red>`, `<#ff8800>`, `<gradient:...>`) atau `&a` — hex otomatis diturunkan ke warna terdekat di bawah 1.16

## Perintah
| Perintah | Fungsi |
|---|---|
| `/menu` | menu utama |
| `/bal [pemain]` | cek saldo (pemain offline juga bisa) |
| `/pay <pemain> <jumlah>` | kirim uang |
| `/shop [kategori]`, `/buy <item> [jumlah]` | toko |
| `/sell [hand\|all\|item] [jumlah]`, `/worth` | jual / cek harga |
| `/bank [deposit\|withdraw\|balance] [jumlah\|all]` | bank |
| `/daily`, `/jobs [join\|leave\|info]`, `/history`, `/note`, `/paytoggle`, `/baltop` | lainnya |

Permission: `ecomenu.<perintah>` (default semua pemain), `ecomenu.admin` (op), `ecomenu.multiplier.<nama>`, `ecomenu.deathpenalty.bypass`.

## Cara dapat file .jar langsung dari GitHub (tanpa build manual)
1. Buat repository baru di GitHub, lalu upload **isi** folder ini (file `pom.xml` harus ada di root repo, folder `.github` ikut terupload).
2. Buka tab **Actions** dan tunggu workflow "Build & Release" selesai (±1-2 menit). Pertama kali, klik "I understand my workflows, go ahead and enable them" kalau diminta.
3. Buka **Releases** (kolom kanan halaman repo) lalu download `EcoMenu-1.1.0.jar` dari release **"EcoMenu - build terbaru"**. Release ini otomatis diperbarui tiap kamu push.
4. Untuk versi resmi: buat tag, mis. `git tag v1.1.0 && git push origin v1.1.0`, maka dibuat release `v1.1.0` dengan jar terlampir.

Kalau Actions gagal membuat release: **Settings → Actions → General → Workflow permissions → Read and write permissions**.

## Build manual
    mvn package          # hasil: target/EcoMenu-1.1.0.jar
Taruh jar di `plugins/`, restart server.

## Catatan kompatibilitas
- Bytecode Java 8, dikompilasi terhadap API 1.16.5. Semua bagian yang berbeda antar versi (nama material, suara, enchant, action bar, data tanaman) ditangani di `Compat.java`.
- Item shop yang belum ada di versi server (mis. `DEEPSLATE` di 1.16) dilewati otomatis; jumlahnya dicatat di console.
- Nama item di config selalu pakai nama modern (`GRASS_BLOCK`, `OAK_LOG`); di server lama dipetakan otomatis.
- Belum mendukung Folia.
- Config lama (v1.0) tetap jalan; hapus `config.yml` lama untuk mendapat kategori shop / job baru, lalu restart.
